import './App.css';
import BackGroundPage from 'pages/BackGroundPage';

function App() {
  return (
    <div className="App">
      <BackGroundPage />
    </div>
  );
}

export default App;
